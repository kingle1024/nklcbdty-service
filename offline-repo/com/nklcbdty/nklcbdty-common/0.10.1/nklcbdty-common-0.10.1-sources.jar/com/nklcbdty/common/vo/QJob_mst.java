package com.nklcbdty.common.vo;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QJob_mst is a Querydsl query type for Job_mst
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QJob_mst extends EntityPathBase<Job_mst> {

    private static final long serialVersionUID = 2062989108L;

    public static final QJob_mst job_mst = new QJob_mst("job_mst");

    public final StringPath annoId = createString("annoId");

    public final StringPath annoSubject = createString("annoSubject");

    public final StringPath classCdNm = createString("classCdNm");

    public final StringPath companyCd = createString("companyCd");

    public final ArrayPath<byte[], Byte> embedding = createArray("embedding", byte[].class);

    public final StringPath embeddingVersion = createString("embeddingVersion");

    public final StringPath empTypeCdNm = createString("empTypeCdNm");

    public final StringPath endDate = createString("endDate");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final DateTimePath<java.time.LocalDateTime> insertDts = createDateTime("insertDts", java.time.LocalDateTime.class);

    public final StringPath jobDetailLink = createString("jobDetailLink");

    public final NumberPath<Long> personalHistory = createNumber("personalHistory", Long.class);

    public final NumberPath<Long> personalHistoryEnd = createNumber("personalHistoryEnd", Long.class);

    public final StringPath startDate = createString("startDate");

    public final StringPath subJobCdNm = createString("subJobCdNm");

    public final StringPath sysCompanyCdNm = createString("sysCompanyCdNm");

    public final DateTimePath<java.time.LocalDateTime> updateDts = createDateTime("updateDts", java.time.LocalDateTime.class);

    public final StringPath workplace = createString("workplace");

    public QJob_mst(String variable) {
        super(Job_mst.class, forVariable(variable));
    }

    public QJob_mst(Path<? extends Job_mst> path) {
        super(path.getType(), path.getMetadata());
    }

    public QJob_mst(PathMetadata metadata) {
        super(Job_mst.class, metadata);
    }

}

