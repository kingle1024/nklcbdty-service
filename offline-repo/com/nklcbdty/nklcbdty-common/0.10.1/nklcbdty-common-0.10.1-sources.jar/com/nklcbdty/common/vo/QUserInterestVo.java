package com.nklcbdty.common.vo;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QUserInterestVo is a Querydsl query type for UserInterestVo
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QUserInterestVo extends EntityPathBase<UserInterestVo> {

    private static final long serialVersionUID = 1865780614L;

    public static final QUserInterestVo userInterestVo = new QUserInterestVo("userInterestVo");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final DateTimePath<java.time.LocalDateTime> insertDts = createDateTime("insertDts", java.time.LocalDateTime.class);

    public final StringPath itemType = createString("itemType");

    public final StringPath itemValue = createString("itemValue");

    public final DateTimePath<java.time.LocalDateTime> updateDts = createDateTime("updateDts", java.time.LocalDateTime.class);

    public final StringPath userId = createString("userId");

    public QUserInterestVo(String variable) {
        super(UserInterestVo.class, forVariable(variable));
    }

    public QUserInterestVo(Path<? extends UserInterestVo> path) {
        super(path.getType(), path.getMetadata());
    }

    public QUserInterestVo(PathMetadata metadata) {
        super(UserInterestVo.class, metadata);
    }

}

